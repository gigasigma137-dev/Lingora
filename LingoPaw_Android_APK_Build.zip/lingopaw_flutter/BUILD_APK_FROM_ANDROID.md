# LingoPaw APK build from an Android phone

This project is source code, not an APK yet. The included GitHub Actions workflow builds the APK in the cloud.

1. Sign in to GitHub in your phone browser and create a new **private** repository named `lingopaw`.
2. Upload the contents of this project ZIP to the repository (keep the `.github/workflows/android-apk.yml` file and its folders).
3. Open the repository's **Actions** tab. If GitHub asks, enable Actions.
4. Choose **Build LingoPaw Android APK** → **Run workflow** → **Run workflow**.
5. Wait for the run to finish successfully. Open the completed run and download the **LingoPaw-Android-APK** artifact.
6. Extract the downloaded artifact ZIP, then tap `app-release.apk` to install it. Android may ask you to allow installs from your browser or file manager.

Notes:
- This produces a test/release APK from the current starter source. Firebase login and cloud features still require Firebase project configuration as described in FIREBASE_SETUP.md.
- Do not publish API keys or signing passwords in a public repository. Use a private repository.
