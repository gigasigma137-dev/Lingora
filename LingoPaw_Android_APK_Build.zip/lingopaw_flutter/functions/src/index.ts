import { initializeApp } from "firebase-admin/app";
import { FieldValue, getFirestore } from "firebase-admin/firestore";
import { onCall, HttpsError } from "firebase-functions/v2/https";

initializeApp();
const db = getFirestore();

/**
 * Call only after validating a real lesson on the server.
 * The client cannot choose the XP amount or write leaderboard scores.
 */
export const completeLesson = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Giriş yapmalısın.");

  const lessonId = request.data?.lessonId;
  if (typeof lessonId !== "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(lessonId)) {
    throw new HttpsError("invalid-argument", "Geçersiz ders.");
  }

  // TODO: Verify lesson answers/progress against server-side lesson content.
  // This starter intentionally does not trust a client-provided score.
  const uid = request.auth.uid;
  const today = new Date().toISOString().slice(0, 10);
  const seasonId = `${today.slice(0, 4)}-W${weekNumber(new Date())}`;
  const completionRef = db.collection("lessonCompletions").doc(`${uid}_${lessonId}_${today}`);
  const userRef = db.collection("users").doc(uid);
  const leaderboardRef = db.collection("leaderboards").doc(seasonId).collection("entries").doc(uid);

  return db.runTransaction(async (tx) => {
    const [done, userSnap] = await Promise.all([tx.get(completionRef), tx.get(userRef)]);
    if (done.exists) return { awarded: false, reason: "already_completed_today" };

    const previous = userSnap.data() ?? {};
    const lastActiveDate = typeof previous.lastActiveDate === "string" ? previous.lastActiveDate : "";
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    const oldStreak = Number.isInteger(previous.streak) ? previous.streak : 0;
    const streak = lastActiveDate === today ? oldStreak : lastActiveDate === yesterday ? oldStreak + 1 : 1;
    const xpAward = 10;
    const xp = (Number.isInteger(previous.xp) ? previous.xp : 0) + xpAward;
    const mascotMood = streak >= 3 ? "happy" : "encouraging";

    tx.set(completionRef, { uid, lessonId, completedAt: FieldValue.serverTimestamp(), xpAward });
    tx.set(userRef, {
      xp, streak, lastActiveDate: today, mascotMood,
      updatedAt: FieldValue.serverTimestamp()
    }, { merge: true });
    tx.set(leaderboardRef, {
      uid, displayName: previous.displayName ?? "Öğrenci",
      xp, updatedAt: FieldValue.serverTimestamp()
    }, { merge: true });
    return { awarded: true, xpAward, xp, streak, mascotMood };
  });
});

function weekNumber(date: Date): string {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const day = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return String(Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7)).padStart(2, "0");
}
