# LingoPaw Firebase kurulum notları

## Gerekli Firebase ürünleri
1. Firebase Console'da proje oluştur.
2. Authentication > Sign-in method: Email/Password ve Google sağlayıcılarını aç.
3. Firestore Database oluştur.
4. Android uygulamasını gerçek `applicationId` ile, web uygulamasını da Firebase projesine ekle.
5. Proje kökünde FlutterFire CLI ile `flutterfire configure` çalıştır. Üretilen `lib/firebase_options.dart` dosyasını repoya ekle (gizli servis hesabı anahtarlarını ekleme).
6. `lib/main.dart` içindeki `firebase_options.dart` import ve `options: DefaultFirebaseOptions.currentPlatform` satırlarını etkinleştir.
7. `flutter pub get` ve `flutter run -d chrome` / Android çalıştırmasını yap.
8. Google sağlayıcısı için Android SHA-1/SHA-256 parmak izlerini Firebase Console'a ekle. Web OAuth istemcisini Firebase'in verdiği yetkili alan adlarıyla yapılandır.
9. `firebase init firestore functions` ile bu repodaki kuralları ve Functions klasörünü projeye bağla. `firebase deploy --only firestore:rules,functions` komutunu çalıştır.

## Veri modeli

- `users/{uid}`: `displayName`, `photoUrl`, `createdAt`, `xp`, `streak`, `lastActiveDate`, `mascotMood`, `updatedAt`.
  - Profil adı/fotoğrafı kullanıcı tarafından düzenlenebilir.
  - XP, seri ve duygu durumu yalnızca güvenilir sunucu fonksiyonundan yazılmalıdır.
- `leaderboards/{seasonId}/entries/{uid}`: `uid`, `displayName`, `xp`, `updatedAt`.
  - Sıralama XP'ye göre azalan okunur; istemci doğrudan yazamaz.
- `lessonCompletions/{uid_lessonId_date}`: ders tamamlanma kaydı ve verilen XP.
  - İstemci yazamaz; sunucu fonksiyonu oluşturur.

## Güvenlik ve üretim notları
- `firestore.rules` istemcinin XP veya lig puanı uydurmasını engeller.
- `functions/src/index.ts` örnek callable fonksiyon içerir; gerçek üründe ders cevapları/progress mutlaka sunucuda doğrulanmalıdır. Şu an örnek fonksiyon 10 XP verir ve aynı kullanıcı/ders/gün için tekrar puan vermemek üzere idempotent kayıt tutar.
- Haftalık sezon kimliği örnek ISO hafta hesabıyla oluşturulur. Üretim öncesi tüm istemciler ve sunucu aynı timezone/hafta başlangıcı standardını kullanmalı.
- Maskot davranışı önerisi: `lastActiveDate` üzerinden 0–1 gün mutlu, 2 gün özlemli, 3–4 gün üzgün, 5+ gün kızgın; mesajlar nazik ve suçluluk hissettirmeyen şekilde olmalı. Kullanıcı bildirimleri kapatabilmeli.
- Bu ortamda Firebase projesine erişim veya Flutter SDK bulunmadığı için gerçek Google OAuth, Android cihaz, web build, Firestore deploy ve Cloud Functions deploy doğrulanmadı.
