# LingoPaw — Flutter starter

Bu proje Android ve Web için tek Flutter kod tabanlı başlangıç sürümüdür.

## İçindekiler
- Türkçe karşılama ve kayıt/giriş ekranı
- Google ile giriş akışı (Firebase yapılandırması gerektirir)
- E-posta/şifre kayıt ve giriş akışı (Firebase yapılandırması gerektirir)
- Ana sayfa, ders listesi, örnek kelime dersi, yarışma/lig ekranı ve profil
- Demo XP, seri ve sıralama verileri

## Çalıştırma
1. Flutter SDK kur: https://docs.flutter.dev/get-started/install
2. Bu klasörde terminal açıp `flutter pub get` çalıştır.
3. Firebase projesi oluştur: https://console.firebase.google.com/
4. Firebase Authentication içinde Google ve Email/Password sağlayıcılarını etkinleştir.
5. FlutterFire CLI kurup `flutterfire configure` çalıştır.
6. `lib/main.dart` içinde `firebase_options.dart` import satırını ve `DefaultFirebaseOptions.currentPlatform` satırını etkinleştir.
7. Web: `flutter run -d chrome`
8. Android: `flutter run` (emülatör veya bağlı telefon)

## Önemli
- Google girişi, gerçek kullanıcı hesapları ve senkronizasyon Firebase projesi yapılandırıldıktan sonra çalışır.
- Yarışma ekranındaki isimler ve XP puanları şimdilik örnek veridir; canlı sıralama değildir.
- Gerçek yarışma için Firestore/Realtime Database, güvenlik kuralları, puan doğrulama ve kötüye kullanım önleme gerekir.
- Gerçek bildirimler için Firebase Cloud Messaging ve Android/iOS/web bildirim izinleri gerekir.
- Bu paket başlangıç prototipidir; mağazaya yüklenmeye hazır, tamamlanmış bir ürün değildir.
