import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

// After running `flutterfire configure`, uncomment the next line and the
// DefaultFirebaseOptions initialization below.
// import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      // options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (_) {
    // Firebase is optional while previewing the UI. Configure it before
    // enabling real account creation or Google sign-in.
  }
  runApp(const LingoPawApp());
}

class LingoPawApp extends StatelessWidget {
  const LingoPawApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LingoPaw',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF69B93B),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F8F0),
        fontFamily: 'Roboto',
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    if (Firebase.apps.isEmpty) return const WelcomePage();
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        return snapshot.data == null ? const WelcomePage() : const MainShell();
      },
    );
  }
}

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});
  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false;

  Future<void> googleLogin() async {
    if (Firebase.apps.isEmpty) {
      _message('Google girişi için önce Firebase kurulumu gerekli.');
      return;
    }
    setState(() => busy = true);
    try {
      final account = await GoogleSignIn().signIn();
      if (account == null) return;
      final tokens = await account.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: tokens.accessToken,
        idToken: tokens.idToken,
      );
      await FirebaseAuth.instance.signInWithCredential(credential);
      if (mounted) Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const MainShell()),
      );
    } catch (e) {
      _message('Google ile giriş yapılamadı: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> emailLogin({required bool create}) async {
    if (Firebase.apps.isEmpty) {
      _message('E-posta girişi için önce Firebase kurulumu gerekli.');
      return;
    }
    setState(() => busy = true);
    try {
      if (create) {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(), password: password.text,
        );
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(), password: password.text,
        );
      }
      if (mounted) Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const MainShell()),
      );
    } on FirebaseAuthException catch (e) {
      _message(e.message ?? 'Bir hata oluştu.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void _message(String value) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 24),
                const Mascot(size: 118),
                const SizedBox(height: 12),
                const Text('LingoPaw', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: Color(0xFF25451E))),
                const Text('Öğren, oyna, geliş!', style: TextStyle(fontSize: 16, color: Colors.black54)),
                const SizedBox(height: 30),
                _field(email, 'E-posta', Icons.email_outlined),
                const SizedBox(height: 12),
                _field(password, 'Şifre', Icons.lock_outline, obscure: true),
                const SizedBox(height: 16),
                SizedBox(width: double.infinity, height: 54, child: FilledButton.icon(
                  onPressed: busy ? null : googleLogin,
                  icon: const Icon(Icons.g_mobiledata, size: 30),
                  label: const Text('Google ile devam et'),
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFF65B936), foregroundColor: Colors.white),
                )),
                const SizedBox(height: 10),
                SizedBox(width: double.infinity, height: 50, child: OutlinedButton(
                  onPressed: busy ? null : () => emailLogin(create: true),
                  child: const Text('E-posta ile kayıt ol'),
                )),
                TextButton(onPressed: busy ? null : () => emailLogin(create: false), child: const Text('Zaten hesabın var mı? Giriş yap')),
                const SizedBox(height: 8),
                TextButton(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell())),
                  child: const Text('Demo olarak keşfet')),
                if (busy) const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController controller, String label, IconData icon, {bool obscure = false}) =>
      TextField(controller: controller, obscureText: obscure, decoration: InputDecoration(
        prefixIcon: Icon(icon), labelText: label, filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
      ));
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [HomePage(), LessonsPage(), CompetitionPage(), ProfilePage()];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: pages[index]),
    bottomNavigationBar: NavigationBar(
      selectedIndex: index,
      onDestinationSelected: (v) => setState(() => index = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Ana sayfa'),
        NavigationDestination(icon: Icon(Icons.menu_book_rounded), label: 'Dersler'),
        NavigationDestination(icon: Icon(Icons.emoji_events_rounded), label: 'Yarışma'),
        NavigationDestination(icon: Icon(Icons.person_rounded), label: 'Profil'),
      ],
    ),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      Row(children: [
        const CircleAvatar(backgroundColor: Color(0xFFE6F5D8), child: Text('🐱', style: TextStyle(fontSize: 25))),
        const SizedBox(width: 10),
        const Expanded(child: Text('Merhaba! Selin 🐾', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 19))),
        _pill('🔥 7'),
        const SizedBox(width: 8),
        _pill('⭐ 850'),
      ]),
      const SizedBox(height: 20),
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(colors: [Color(0xFFB9E9FF), Color(0xFFE5F8FF)]),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Bugünkü hedefin', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Bir ders tamamla ve serini koru!'),
          const SizedBox(height: 12),
          const Center(child: Mascot(size: 100)),
          SizedBox(width: double.infinity, child: FilledButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LessonPlayPage())),
            child: const Text('Derse başla  →'),
          )),
        ]),
      ),
      const SizedBox(height: 18),
      const Text('Derslerin', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      const Row(children: [
        Expanded(child: FeatureTile(icon: Icons.translate, title: 'Kelime', color: Color(0xFFFFE7A8))),
        SizedBox(width: 9),
        Expanded(child: FeatureTile(icon: Icons.headphones, title: 'Dinleme', color: Color(0xFFDDEBFF))),
        SizedBox(width: 9),
        Expanded(child: FeatureTile(icon: Icons.mic, title: 'Konuşma', color: Color(0xFFFFDCEB))),
      ]),
      const SizedBox(height: 18),
      const Text('Günlük görevler', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const TaskTile(title: '1 ders tamamla', progress: '0 / 1'),
      const TaskTile(title: '5 yeni kelime öğren', progress: '2 / 5'),
      const TaskTile(title: 'Yarışmada puan kazan', progress: '0 / 1'),
    ],
  );
}

class LessonsPage extends StatelessWidget {
  const LessonsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Dersler', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
    const Text('İngilizce • Başlangıç seviyesi'),
    const SizedBox(height: 18),
    ...['Temel kelimeler', 'Selamlaşma', 'Yiyecekler', 'Günlük konuşmalar'].asMap().entries.map((e) =>
      Card(child: ListTile(
        leading: CircleAvatar(backgroundColor: const Color(0xFFE7F5D9), child: Text('${e.key + 1}')),
        title: Text(e.value), subtitle: const Text('10 kısa soru • XP kazan'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LessonPlayPage())),
      ))),
  ]);
}

class CompetitionPage extends StatelessWidget {
  const CompetitionPage({super.key});
  @override
  Widget build(BuildContext context) {
    final players = [('Mira', '5.240'), ('Selin', '4.810'), ('Deniz', '4.560'), ('Ege', '4.120'), ('Luna', '3.980')];
    return ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Yarışma 🏆', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6),
      const Text('Bu haftanın liginde diğer öğrencilerle yarış!'),
      const SizedBox(height: 16),
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(
        color: const Color(0xFFE4F4D7), borderRadius: BorderRadius.circular(24)),
        child: const Column(children: [
          Text('💎', style: TextStyle(fontSize: 54)),
          Text('Zümrüt Ligi', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
          Text('Haftanın bitmesine 3 gün 14 saat'),
          SizedBox(height: 8),
          Text('İlk 3’e gir, özel rozet kazan!', style: TextStyle(fontWeight: FontWeight.w600)),
        ]),
      ),
      const SizedBox(height: 18),
      const Text('Haftalık sıralama', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      ...players.asMap().entries.map((e) => Card(
        color: e.key == 1 ? const Color(0xFFEAF8D9) : Colors.white,
        child: ListTile(
          leading: CircleAvatar(child: Text('${e.key + 1}')),
          title: Text(e.value.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
          trailing: Text('${e.value.$2} XP', style: const TextStyle(fontWeight: FontWeight.bold)),
        ),
      )),
      const SizedBox(height: 8),
      const Text('Not: Bu sıralama şu an demo verisidir. Gerçek çevrimiçi yarışma için veritabanı ve sunucu kurulacak.',
        style: TextStyle(color: Colors.black54, fontSize: 12)),
    ]);
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Center(child: Mascot(size: 110)),
    const Center(child: Text('Selin', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
    const Center(child: Text('Seviye 3 • 850 XP')),
    const SizedBox(height: 20),
    const TaskTile(title: 'Tamamlanan dersler', progress: '12'),
    const TaskTile(title: 'En uzun seri', progress: '7 gün'),
    const TaskTile(title: 'Kazanılan rozetler', progress: '4'),
    const SizedBox(height: 12),
    OutlinedButton.icon(
      onPressed: Firebase.apps.isEmpty ? null : () async {
        await FirebaseAuth.instance.signOut();
        await GoogleSignIn().signOut();
        if (context.mounted) Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (_) => const WelcomePage()), (_) => false);
      },
      icon: const Icon(Icons.logout), label: const Text('Çıkış yap'),
    ),
  ]);
}

class LessonPlayPage extends StatefulWidget {
  const LessonPlayPage({super.key});
  @override
  State<LessonPlayPage> createState() => _LessonPlayPageState();
}

class _LessonPlayPageState extends State<LessonPlayPage> {
  int selected = -1;
  bool checked = false;
  final options = ['Elma', 'Kitap', 'Kedi', 'Ev'];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('İngilizce • 1. Ders')),
    body: Padding(padding: const EdgeInsets.all(22), child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const LinearProgressIndicator(value: 0.3, minHeight: 9),
        const SizedBox(height: 28),
        const Text('Bu kelimenin İngilizcesi nedir?', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 22),
        const Center(child: Text('🍎', style: TextStyle(fontSize: 90))),
        const Center(child: Text('ELMA', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
        const SizedBox(height: 20),
        ...options.asMap().entries.map((e) => Padding(
          padding: const EdgeInsets.only(bottom: 9),
          child: OutlinedButton(
            style: OutlinedButton.styleFrom(
              backgroundColor: selected == e.key ? const Color(0xFFE7F6D8) : Colors.white,
              padding: const EdgeInsets.all(16),
            ),
            onPressed: checked ? null : () => setState(() => selected = e.key),
            child: Text(e.value, style: const TextStyle(fontSize: 17)),
          ),
        )),
        const Spacer(),
        if (checked) const Text('Harika! Doğru cevap: Apple 🍏', textAlign: TextAlign.center,
          style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
        FilledButton(
          onPressed: selected < 0 ? null : () {
            if (!checked) setState(() => checked = true);
            else Navigator.pop(context);
          },
          child: Text(checked ? 'Devam et' : 'Kontrol et'),
        ),
      ],
    )),
  );
}

class Mascot extends StatelessWidget {
  final double size;
  const Mascot({super.key, required this.size});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: size, height: size,
    child: Center(child: Text('🐱', style: TextStyle(fontSize: size * .78))),
  );
}

class FeatureTile extends StatelessWidget {
  final IconData icon; final String title; final Color color;
  const FeatureTile({super.key, required this.icon, required this.title, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
    decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(18)),
    child: Column(children: [Icon(icon, size: 27), const SizedBox(height: 6), Text(title, style: const TextStyle(fontWeight: FontWeight.bold))]),
  );
}

class TaskTile extends StatelessWidget {
  final String title; final String progress;
  const TaskTile({super.key, required this.title, required this.progress});
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(leading: const Icon(Icons.stars_rounded, color: Color(0xFFE6A900)),
      title: Text(title), trailing: Text(progress, style: const TextStyle(fontWeight: FontWeight.bold))),
  );
}

Widget _pill(String text) => Container(
  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
  child: Text(text, style: const TextStyle(fontWeight: FontWeight.bold)),
);
