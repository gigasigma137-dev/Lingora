import 'package:cloud_firestore/cloud_firestore.dart';

class LeaderboardEntry {
  final String uid;
  final String displayName;
  final int xp;

  const LeaderboardEntry({
    required this.uid,
    required this.displayName,
    required this.xp,
  });

  factory LeaderboardEntry.fromMap(String uid, Map<String, dynamic> data) {
    return LeaderboardEntry(
      uid: uid,
      displayName: (data['displayName'] as String?) ?? 'Öğrenci',
      xp: (data['xp'] as num?)?.toInt() ?? 0,
    );
  }
}

class LeaderboardService {
  final FirebaseFirestore firestore;
  LeaderboardService({FirebaseFirestore? firestore})
      : firestore = firestore ?? FirebaseFirestore.instance;

  Stream<List<LeaderboardEntry>> watchWeeklyLeague(String seasonId) {
    return firestore
        .collection('leaderboards')
        .doc(seasonId)
        .collection('entries')
        .orderBy('xp', descending: true)
        .limit(50)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => LeaderboardEntry.fromMap(doc.id, doc.data()))
            .toList(growable: false));
  }
}
